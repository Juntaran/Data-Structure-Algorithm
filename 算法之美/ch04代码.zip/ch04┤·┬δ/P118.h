template <class T> class Iterator{

	ListNode<T>* cur;

	public:
		Iterator():cur(NULL){};
		Iterator(ListNode<T>* point):cur(point){}

		friend T operator ++(Iterator& it);		//ǰ׺
		friend T operator ++ (Iterator& it,int);	//��׺

		friend bool operator == (Iterator& it,ListNode<T>* point);
		friend bool operator !=  (Iterator& it,ListNode<T>* point);
		friend ostream& operator<< (ostream& stream,Iterator& it);

		void operator= (ListNode<T>* point);
		ListNode<T>*& GetCur();
};
