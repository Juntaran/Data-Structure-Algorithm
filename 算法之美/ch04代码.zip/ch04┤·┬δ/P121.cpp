template <class T> 
T operator++(Iterator<T>& it){
	it.GetCur() = it.GetCur()->GetLink();
	T data;
	data = it.GetCur()->GetData();
	return data;
}

template <class T> 
T operator++(Iterator<T>& it,int){
	T data;
	data = it.GetCur()->GetData();
	it.GetCur() = it.GetCur()->GetLink();
	return data;
}

template <class T> 
T operator--(Iterator<T>& it){
	it.GetCur() = it.GetCur()->GetPrior();
	T data;
	data = it.GetCur()->GetData();
	return data;
}

template <class T> 
T operator--(Iterator<T>& it,int){
	T data;
	data = it.GetCur()->GetData();
	it.GetCur() = it.GetCur()->GetPrior();
	return data;
}

template <class T> 
bool operator==(Iterator<T>& it,DouListNode<T>* point){
	return it.GetCur() == point;
}

template <class T>
bool operator!=(Iterator<T>& it,DouListNode<T>* point){
	return it.GetCur() != point;
}

template <class T> 
ostream& operator<<(ostream& stream,Iterator<T>& it){
	stream<<it.GetCur()->GetData();
	return stream;
}

template <class T>
void Iterator<T>::operator = (DouListNode<T>* point){
	cur = point;
}

template <class T> 
DouListNode<T>*& Iterator<T>::GetCur(){
	return cur;
}
