template <class T> class Iterator{

	DouListNode<T>* cur;

	public:
		Iterator():cur(NULL){};
		Iterator(DouListNode<T>* point):cur(point){}
		friend T operator++(Iterator& it);			//ǰ׺
		friend T operator++(Iterator& it,int);		//��׺
		friend T operator--(Iterator& it);			//ǰ׺
		friend T operator--(Iterator& it,int);		//��׺
		friend bool operator==(Iterator& it,DouListNode<T>* point);
		friend bool operator!=(Iterator& it,DouListNode<T>* point);
		friend ostream& operator<< (ostream& stream,Iterator& it);
		void operator= (DouListNode<T>* point);
		DouListNode<T>*& GetCur();
};
