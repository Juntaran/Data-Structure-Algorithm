//前缀运算符，先返回cur所指结点中的数据
//再使cur向后移动
template <class T> 
T operator++(Iterator<T>& it){ 
it.GetCur() = it.GetCur()->GetLink();
T data;
data = it.GetCur()->GetData();
	return data;
}

//后缀运算符，先使cur向后移动一个结点
//再返回cur所指结点中的数据
template <class T> 
T operator++(Iterator<T>& it,int){
	T data;
	data = it.GetCur()->GetData();
	it.GetCur() = it.GetCur()->GetLink();
	return data;
}

//判断cur是否等于point
template <class T>
bool operator==(Iterator<T>& it,ListNode<T>* point){
	return it.GetCur() == point;
}

//判断cur是否不等于point
template <class T>
bool operator!=(Iterator<T>& it,ListNode<T>* point){
	return it.GetCur() != point;
}

//输出cur所指结点中的数据
template <class T> 
ostream& operator<<(ostream& stream,Iterator<T>& it){
	stream<<it.GetCur()->GetData();
	return stream;
}

//把point的值赋给cur
template <class T>
void Iterator<T>::operator = (ListNode<T>* point){
	cur = point;
}

//返回cur
template <class T>
ListNode<T>*& Iterator<T>::GetCur(){
	return cur;
}
