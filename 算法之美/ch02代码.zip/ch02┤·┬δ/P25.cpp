
#include "stdafx.h"
#pragma runtime_checks( "", off )

int _tmain(int argc, _TCHAR* argv[])
{
	int a = 97;
	int b = 98;
	int c = 99;

	return 0;
}

