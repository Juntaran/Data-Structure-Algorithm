#include <iostream>

using namespace std;

int main(int argc, char* argv[]) {

	int a[5] = {1, 2, 3, 4, 5};
	int b[5] = {6, 7, 8, 9, 10};

cout << b[6] << endl;
return 0;
}
