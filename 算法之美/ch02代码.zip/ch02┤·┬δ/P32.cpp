#include <iostream>

using namespace std;

void fun(int x)
{
	cout<< ��x = ��<<x<<endl;
	x++;
	cout<< ��x = ��<<x<<endl;
}

int main(int argc, char** argv) {

	int x = 0;
	cout<<"x = " <<x<<endl;
	fun(x);
	cout<<"x = " <<x<<endl;

	return 0;
}
