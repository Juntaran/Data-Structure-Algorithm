// DSPS503.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "LinkQueue.h"
#include <string>
#include <iostream>

using namespace std;

struct dancer{
	string name;
	char sex;
};

int _tmain(int argc, _TCHAR* argv[])
{
	cout<<"��������������:";
	int num;
	cin>>num;
	LinkQueue<dancer> Mdancer;
	LinkQueue<dancer> Fdancer;
	for(int i=0;i<num;i++){
		cout<<"�����������Ա�(f or m)������:";
		char sex;
		cin>>sex;
		string name;
		cin>>name;
		dancer newdancer;
		newdancer.name = name;
		newdancer.sex = sex;
		if(sex == 'f')
			Fdancer.EnQueue(newdancer);
		if(sex == 'm')
			Mdancer.EnQueue(newdancer);
	}

	while(!Mdancer.IsEmpty() && !Fdancer.IsEmpty()){
		cout<<Mdancer.DelQueue().name<<"\t<---->\t"<<Fdancer.DelQueue().name<<endl;
	}

	if(!Mdancer.IsEmpty()){
		cout<<"Mr. "<<Mdancer.GetFront().name<<" is waiting!"<<endl;
	}
	else if(!Fdancer.IsEmpty()){
		cout<<"Ms. "<<Fdancer.GetFront().name<<" is waiting!"<<endl;
	}
	else
		cout<<"OK!"<<endl;

	system("PAUSE");
	return 0;
}