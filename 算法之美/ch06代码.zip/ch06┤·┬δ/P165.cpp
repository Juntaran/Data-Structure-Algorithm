#include "stdio.h"

void recursiveFunction1 ( int num ) 
{ 
	if ( num < 5 ) 
	{ 
		printf ( "%d \n" , num ) ; 
		recursiveFunction1 ( num +1 ) ; 
	} 
}

void recursiveFunction2 ( int num ) 
{ 
	if ( num < 5 ) 
	{ 
		recursiveFunction2 ( num +1 ) ; 
		printf ( "%d \n" , num ) ; 
	}
}

void main()
{
	recursiveFunction1(0);
	recursiveFunction2(0);
}

